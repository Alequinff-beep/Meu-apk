COMO GERAR O APK
1. Instale o Android Studio (https://developer.android.com/studio).
2. File > Open > escolha a pasta MeusProjetosPython. Espere o Gradle sincronizar (precisa de internet).
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
   O arquivo sai em app/build/outputs/apk/debug/app-debug.apk
4. Passe pro celular e instale (permita "fontes desconhecidas").

COMO USAR
- "Novo": cria um projeto com main.py.
- "Importar pasta": copia uma pasta do celular (ex.: Downloads) pro app.
- Toque no projeto: escolha o arquivo .py, edite, Salvar e ▶ Rodar.
- Toque longo no projeto: apagar.

BIBLIOTECAS
Edite app/build.gradle.kts, bloco pip { install("requests") }, e adicione as suas.
Obs.: input() não funciona (devolve fim de entrada); bibliotecas precisam ter versão pra Android (numpy, pandas, etc. têm).
