package com.meusprojetos

import android.graphics.Typeface
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import java.io.File

interface OutputCallback { fun onText(s: String) }

class ProjectActivity : AppCompatActivity() {
    private lateinit var dir: File
    private lateinit var editor: EditText
    private lateinit var output: TextView
    private lateinit var scroll: ScrollView
    private var files = listOf<String>()
    private var current: String? = null
    @Volatile private var running = false

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!Python.isStarted()) Python.start(AndroidPlatform(this))
        val name = intent.getStringExtra("name") ?: return finish()
        title = name
        dir = File(File(filesDir, "projetos"), name)

        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8), dp(8), dp(8), dp(8)) }
        val spinner = Spinner(this)
        col.addView(spinner)

        editor = EditText(this).apply {
            typeface = Typeface.MONOSPACE; textSize = 13f; gravity = android.view.Gravity.TOP
            setHorizontallyScrolling(true)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE or android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        }
        col.addView(editor, LinearLayout.LayoutParams(-1, 0, 2f))

        val bar = LinearLayout(this)
        val lp = LinearLayout.LayoutParams(0, -2, 1f)
        bar.addView(Button(this).apply { text = "Salvar"; setOnClickListener { save(); toast("Salvo") } }, lp)
        bar.addView(Button(this).apply { text = "▶ Rodar"; setOnClickListener { run() } }, lp)
        bar.addView(Button(this).apply { text = "Limpar"; setOnClickListener { output.text = "" } }, lp)
        col.addView(bar)

        output = TextView(this).apply { typeface = Typeface.MONOSPACE; textSize = 12f; setTextIsSelectable(true); setPadding(dp(6), dp(6), dp(6), dp(6)) }
        scroll = ScrollView(this).apply { addView(output); setBackgroundColor(0x22000000) }
        col.addView(scroll, LinearLayout.LayoutParams(-1, 0, 2f))
        setContentView(col)

        files = dir.walkTopDown().filter { it.isFile && it.extension == "py" }
            .map { it.relativeTo(dir).path }.sortedWith(compareBy({ it != "main.py" }, { it })).toList()
        if (files.isEmpty()) { toast("Nenhum arquivo .py nesse projeto"); return }
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, files)
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                save(); current = files[pos]; editor.setText(File(dir, files[pos]).readText())
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
    }

    private fun save() { current?.let { File(dir, it).writeText(editor.text.toString()) } }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    override fun onPause() { super.onPause(); save() }

    private fun append(s: String) = runOnUiThread { output.append(s); scroll.post { scroll.fullScroll(View.FOCUS_DOWN) } }

    private fun run() {
        val file = current ?: return
        if (running) { toast("Já está rodando"); return }
        save(); running = true
        output.text = "▶ $file\n"
        Thread {
            try {
                Python.getInstance().getModule("runner")
                    .callAttr("run_file", dir.absolutePath, file, object : OutputCallback {
                        override fun onText(s: String) = append(s)
                    })
            } catch (e: Exception) { append("\n[erro interno] ${e.message}\n") }
            append("\n✔ fim\n"); running = false
        }.start()
    }
}
