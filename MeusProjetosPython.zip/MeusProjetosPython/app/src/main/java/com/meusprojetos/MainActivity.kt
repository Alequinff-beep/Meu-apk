package com.meusprojetos

import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.documentfile.provider.DocumentFile
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import java.io.File

class MainActivity : AppCompatActivity() {
    private val names = mutableListOf<String>()
    private lateinit var adapter: ArrayAdapter<String>
    private val root get() = File(filesDir, "projetos").apply { mkdirs() }

    private val pickDir =
        registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
            if (uri != null) importTree(uri)
        }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!Python.isStarted()) Python.start(AndroidPlatform(this))
        title = "Meus Projetos Python"

        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(12), dp(12), dp(12)) }
        val bar = LinearLayout(this)
        val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        bar.addView(Button(this).apply { text = "Novo"; setOnClickListener { newProject() } }, lp)
        bar.addView(Button(this).apply { text = "Importar pasta"; setOnClickListener { pickDir.launch(null) } }, lp)
        col.addView(bar)

        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, names)
        val list = ListView(this).apply { adapter = this@MainActivity.adapter }
        list.setOnItemClickListener { _, _, i, _ ->
            startActivity(Intent(this, ProjectActivity::class.java).putExtra("name", names[i]))
        }
        list.setOnItemLongClickListener { _, _, i, _ ->
            AlertDialog.Builder(this).setTitle("Apagar \"${names[i]}\"?")
                .setPositiveButton("Apagar") { _, _ -> File(root, names[i]).deleteRecursively(); refresh() }
                .setNegativeButton("Cancelar", null).show()
            true
        }
        col.addView(list)
        setContentView(col)
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun refresh() {
        names.clear()
        names.addAll(root.listFiles()?.filter { it.isDirectory }?.map { it.name }?.sorted() ?: emptyList())
        adapter.notifyDataSetChanged()
    }

    private fun newProject() {
        val input = EditText(this).apply { hint = "nome-do-projeto" }
        AlertDialog.Builder(this).setTitle("Novo projeto").setView(input)
            .setPositiveButton("Criar") { _, _ ->
                val n = input.text.toString().trim().replace(Regex("[^A-Za-z0-9_\\-]"), "_")
                if (n.isNotEmpty()) {
                    val d = File(root, n).apply { mkdirs() }
                    File(d, "main.py").writeText("print(\"Olá do Python no Android!\")\n")
                    refresh()
                }
            }.setNegativeButton("Cancelar", null).show()
    }

    private fun importTree(uri: Uri) {
        val doc = DocumentFile.fromTreeUri(this, uri) ?: return
        val dest = File(root, doc.name ?: "projeto")
        Toast.makeText(this, "Importando...", Toast.LENGTH_SHORT).show()
        Thread {
            try {
                copyTree(doc, dest)
                runOnUiThread { refresh(); Toast.makeText(this, "Importado!", Toast.LENGTH_SHORT).show() }
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this, "Erro: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }.start()
    }

    private fun copyTree(src: DocumentFile, dest: File) {
        dest.mkdirs()
        for (c in src.listFiles()) {
            val n = c.name ?: continue
            if (c.isDirectory) {
                if (n == ".git" || n == "__pycache__") continue
                copyTree(c, File(dest, n))
            } else {
                contentResolver.openInputStream(c.uri)?.use { i ->
                    File(dest, n).outputStream().use { o -> i.copyTo(o) }
                }
            }
        }
    }
}
