import os
import runpy
import sys
import io
import traceback


class _Out:
    def __init__(self, cb):
        self.cb = cb

    def write(self, s):
        if s:
            self.cb.onText(s)
        return len(s)

    def flush(self):
        pass


def run_file(project_dir, rel_path, cb):
    old_out, old_err, old_in = sys.stdout, sys.stderr, sys.stdin
    old_cwd, old_path = os.getcwd(), list(sys.path)
    sys.stdout = sys.stderr = _Out(cb)
    sys.stdin = io.StringIO("")  # input() não é suportado: devolve EOF
    os.chdir(project_dir)
    sys.path.insert(0, project_dir)
    try:
        runpy.run_path(os.path.join(project_dir, rel_path), run_name="__main__")
    except SystemExit:
        pass
    except BaseException:
        traceback.print_exc()
    finally:
        sys.stdout, sys.stderr, sys.stdin = old_out, old_err, old_in
        os.chdir(old_cwd)
        sys.path[:] = old_path
        # esquece módulos do projeto para a próxima execução pegar o código novo
        for name, mod in list(sys.modules.items()):
            f = getattr(mod, "__file__", None)
            if f and f.startswith(project_dir):
                del sys.modules[name]
